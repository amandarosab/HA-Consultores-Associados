<?php 
/**
 * Template Name: Termos de Uso
 */
get_header();
 ?>
<main id="primary" class="site-main">
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Termos de Uso | Hélio Amado Consultores Associados</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="main-styles.css">
  <link rel="stylesheet" href="fonts.css">
  <style>
    body {
      background: #000 !important;
      color: #fff !important;
    }
    a { color: #fff; }
  </style>
</head>
<body class="bg-base text-white">
  <div class="container py-16 md:py-24">
    <h1 class="big-title mb-8">Termos de Uso</h1>
    <p class="text-lg mb-6">Estes Termos de Uso regulam o acesso e a utilização do site Hélio Amado Consultores Associados, em conformidade com a Lei Geral de Proteção de Dados (LGPD).</p>
    
    <h2 class="section-title mt-10 mb-4">1. Aceitação dos Termos</h2>
    <p class="mb-4">Ao acessar ou utilizar este site, você concorda com estes Termos de Uso e com a nossa <a href="privacy-notice.html" class="underline">Política de Privacidade</a>.</p>
    
    <h2 class="section-title mt-10 mb-4">2. Uso do Site</h2>
    <p class="mb-4">Você se compromete a utilizar o site de forma ética, respeitando a legislação vigente e os direitos de terceiros. É proibido utilizar o site para fins ilícitos ou que possam prejudicar terceiros.</p>
    
    <h2 class="section-title mt-10 mb-4">3. Propriedade Intelectual</h2>
    <p class="mb-4">Todo o conteúdo deste site, incluindo textos, imagens, logotipos e marcas, é protegido por direitos autorais e pertence a Hélio Amado Consultores Associados, salvo indicação em contrário. É proibida a reprodução ou distribuição sem autorização prévia.</p>
    
    <h2 class="section-title mt-10 mb-4">4. Proteção de Dados</h2>
    <p class="mb-4">Os dados pessoais fornecidos por você serão tratados conforme a nossa <a href="privacy-notice.html" class="underline">Política de Privacidade</a> e em conformidade com a LGPD.</p>
    
    <h2 class="section-title mt-10 mb-4">5. Limitação de Responsabilidade</h2>
    <p class="mb-4">Não nos responsabilizamos por danos decorrentes do uso indevido do site ou por indisponibilidades temporárias.</p>
    
    <h2 class="section-title mt-10 mb-4">6. Alterações nos Termos</h2>
    <p class="mb-4">Estes Termos de Uso podem ser alterados a qualquer momento. Recomendamos a revisão periódica deste documento.</p>
    
    <h2 class="section-title mt-10 mb-4">7. Contato</h2>
    <p class="mb-4">Em caso de dúvidas sobre estes Termos de Uso, entre em contato pelo e-mail <a href="mailto:contato@helioamado.com.br" class="underline">contato@helioamado.com.br</a>.</p>
    
    <hr class="bg-white w-4/5 mx-auto opacity-60 my-14">
    <p class="text-sm opacity-60">Última atualização: Julho de 2025</p>
  </div>
</body>
</html>
</main>
<?php get_footer(); ?>