<?php /* Template Name: Front Page */ ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="UTF-8">
  <meta property="og:type" content="website" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="profile" href="https://gmpg.org/xfn/11">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="fonts.css">
  <meta name="google-site-verification" content="1tTGLxnMpqPeR3UrMsevti0OeCHmph1_ICEwmEtIaWY" />

  <title>Hélio Amado Consultores Associados</title>

  <meta property="og:title" content="Hélio Amado Consultores Associados">

  <meta property="og:site_name" content="Hélio Amado Consultores Associados"/>
  <link rel="icon" type="image/png" sizes="192x192" href="favicon.png">

  <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />
  <link rel="stylesheet" href="responsive_images.css">

  <meta property="og:locale" content="en_US" />
  <meta property="og:type" content="article" />
  <meta property="og:title" content="Hélio Amado Consultores Associados" />

  <meta property="og:site_name" content="Hélio Amado Consultores Associados" />
  <meta property="article:modified_time" content="2025-03-13T14:46:03+00:00" />
  <meta name="twitter:card" content="summary_large_image" />
  <!--<script type="application/ld+json" class="yoast-schema-graph">
    {
      "@context": "https://schema.org",
      "@graph": [{
        "@type": "WebPage",
        "@id": "https://www.dsgco.com/consulting/",
        "url": "https://www.dsgco.com/consulting/",
        "name": "Consulting - DSG Global",
        "isPartOf": {
          "@id": "https://www.dsgco.com/#website"
        },
        "datePublished": "2024-10-03T01:32:55+00:00",
        "dateModified": "2025-03-13T14:46:03+00:00",
        "breadcrumb": {
          "@id": "https://www.dsgco.com/consulting/#breadcrumb"
        },
        "inLanguage": "en-US",
        "potentialAction": [{
          "@type": "ReadAction",
          "target": ["https://www.dsgco.com/consulting/"]
        }]
      }, {
        "@type": "BreadcrumbList",
        "@id": "https://www.dsgco.com/consulting/#breadcrumb",
        "itemListElement": [{
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.dsgco.com/"
        }, {
          "@type": "ListItem",
          "position": 2,
          "name": "Consulting"
        }]
      }, {
        "@type": "WebSite",
        "@id": "https://www.dsgco.com/#website",
        "url": "https://www.dsgco.com/",
        "name": "Diversified Search Group",
        "description": "",
        "publisher": {
          "@id": "https://www.dsgco.com/#organization"
        },
        "potentialAction": [{
          "@type": "SearchAction",
          "target": {
            "@type": "EntryPoint",
            "urlTemplate": "https://www.dsgco.com/?s={search_term_string}"
          },
          "query-input": {
            "@type": "PropertyValueSpecification",
            "valueRequired": true,
            "valueName": "search_term_string"
          }
        }],
        "inLanguage": "en-US"
      }, {
        "@type": "Organization",
        "@id": "https://www.dsgco.com/#organization",
        "name": "Diversified Search Group",
        "url": "https://www.dsgco.com/",
        "logo": {
          "@type": "ImageObject",
          "inLanguage": "en-US",
          "@id": "https://www.dsgco.com/#/schema/logo/image/",
          "url": "https://www.dsgco.com/wp-content/uploads/2024/09/logo-alt.svg",
          "contentUrl": "https://www.dsgco.com/wp-content/uploads/2024/09/logo-alt.svg",
          "width": 142,
          "height": 32,
          "caption": "Diversified Search Group"
        },
        "image": {
          "@id": "https://www.dsgco.com/#/schema/logo/image/"
        }
      }]
    }
  </script> -->

  <!-- Emoji detection -->
  <script defer src="/js/emoji-detection.js"></script>

  <link rel="stylesheet" href="component-styles.css">
  <link rel="stylesheet" href="wp-emoji-styles-inline-css.css">
  <link rel="stylesheet" href="global-styles-inline-css.css">
  <link rel="stylesheet" href="nav-button-wordpress.css">
  <link rel="stylesheet" href="akismet-widget-style-inline-css.css">
  <link rel="https://api.w.org/" href="https://www.dsgco.com/wp-json/" />
  <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.dsgco.com/xmlrpc.php?rsd" />
  <link rel='shortlink' href='https://www.dsgco.com/?p=3562' />
  <link rel="stylesheet" href="wp-fonts-local.css">
  <link rel="stylesheet" href="wp-custom-css.css">
  <!-- Google Tag Manager – precisa ser o 1.º script executado -->
  <script defer src="/js/gtm-loader.js"></script>
  <script type="text/javascript"
    src="https://cdn.cookielaw.org/consent/01924956-ec3e-75ad-95f8-d67c8aedc8bd/OtAutoBlock.js"></script>
  <script src="https://cdn.cookielaw.org/scripttemplates/otSDKStub.js" type="text/javascript" charset="UTF-8"
    data-domain-script="01924956-ec3e-75ad-95f8-d67c8aedc8bd"></script>
  <!-- OneTrust wrapper, depois dos dois .js externos da OneTrust -->
  <script defer src="/js/otwrapper.js"></script>

<style>
  /* HEADER overrides */
  #js-header .container{max-width:1280px;margin:0 auto;padding-left:1.5rem;padding-right:1.5rem;}
  #js-menu .header__nav{list-style:none;margin:0;padding:0;display:flex;align-items:center;gap:2.5rem;}
  #js-menu .header__nav>li{margin:0;}
  #js-menu .header__nav>li>a{color:#fff;text-decoration:none;font-weight:500;line-height:1;}
  #js-menu .header__nav>li>a::after{content:none!important;}
  #js-menu .header__nav>li>a i{display:none!important;}
  .header__link--cta{padding:6px 1.25rem;border:2px solid #fff;border-radius:9999px;}
  .header__link--cta:hover{background:#fff;color:#000;}

  /* FOOTER copyright center */
  .footer__copyright{display:block;width:100%;text-align:center;margin-top:2rem;}
  .footer__copyright small{display:inline-block;}

  /* Footer link reset (opcional) */
  .footer a{text-decoration:none;}
  .footer a:hover{text-decoration:underline;}
</style>

<!-- Let WP print all your enqueued styles & scripts -->
<?php wp_head(); ?>
</head>
<body id="topo" <?php body_class(); ?> >
<body class="page-template page-template-page-builder page-template-page-builder-php page page-id-3562">

  <div class="overlay" id="js-overlay"></div>

<header class="header py-3 md:py-5 absolute w-full z-20" id="js-header">
  <div class="container flex items-center justify-between">
    <a href="#topo" class="flex items-center gap-x-2 no-underline">
      <span class="sr-only">Hélio Amado Consultores Associados</span>
      <span class="text-1xl font-bold leading-tight text-white" id="js-header-logo">
        Hélio Amado & Consultores Associados
      </span>
    </a>

    <nav class="lhs flex items-center" id="js-menu">
      <ul class="header__nav flex items-center gap-x-10 text-base tracking-tight">
        <li><a href="#topo" class="header__link">Início</a></li>
        <li><a href="#sobre-nos" class="header__link">Sobre nós</a></li>
        <li><a href="#nossos-servicos" class="header__link">Nossos serviços</a></li>
        <li><a href="#contato" class="header__link header__link--cta">Contato</a></li>
      </ul>
    </nav>

    <!-- Hamburger visível apenas mobile; mantém se precisar JS -->
    <button class="header__hamburger lg:hidden" id="js-toggle-menu" aria-label="Abrir menu">
      <span></span><span></span><span></span>
    </button>
  </div>
</header>
  <main>

    <section class="hero hero--consulting bg-base relative overflow-hidden">
      <div class="hero__bg hero__bg--consulting absolute">
        <div class="hero__gradients">
          <div class="hero__gradient-1"></div>
          <div class="hero__gradient-2"></div>
          <div class="hero__gradient-3"></div>
          <div class="hero__gradient-4"></div>
        </div>
        <div class="hero__lines js-hero-bg">
        </div>
      </div>
      <div
        class="hero__container container w-screen h-screen flex items-end md:items-start lg:items-end md:pt-40 lg:pt-0 pb-10 md:pb-20">
        <div class="hero__content lg:w-5/12 text-white text-center relative z-10 js-hero-content">
          <h1 class="big-title text-balance">
            Hélio Amado<br>
            <span class="ajuste-linha">Consultores Associados</span>
          </h1>
          <p class="mt-5 md:mt-7 text-balance">Fomos criados para apoiar pequenas e médias empresas com soluções estratégicas acessíveis e humanizadas. </p>
          <div class="hero__buttons flex gap-x-2 justify-center md:justify-start mt-6 md:mt-8">
            <a href="https://wa.me/5511995316375?text=Olá!%20Gostaria%20de%20mais%20informações." target="_blank" rel="noopener" class="button button--white">Contate<i></i></a>
          </div>
        </div>
      </div>
    </section>
      <section id="sobre-nos">
        <!-- conteúdo da seção -->
      </section>
    <section class="py-16 lg:py-24">
      <div class="container js-scroll-activate">
        <div class="md:w-1/2 mx-auto md:text-center">
          <h2 class="big-title"><span>Sobre nós</span></h2>
          <p class="text-lg text-secondary mt-4 text-balance"><br>Somos uma equipe de consultores especialistas em apoiar pequenas e médias empresas em sua jornada de crescimento sustentável. </br> <br>Nossa abordagem combina expertise técnica com um olhar humanizado, oferecendo soluções práticas e acessíveis que se adaptam à realidade do empreendedor brasileiro.
          <br></br>Liderada por Hélio Amado, profissional com mais de 15 anos de experiência em gestão estratégica e desenvolvimento empresarial.</br></p>
      </section>
        </div>
      </div>
    </section>
    <div class="container">
      <hr class="bg-white w-full opacity-60 my-14">
    </div>    
    <section id="nossos-servicos">
        <!-- conteúdo da seção -->
      </section>
    <section class="py-16 lg:py-24">
      <div class="container js-scroll-activate">
        <div class="md:w-1/2 mx-auto md:text-center">
          <h3 class="big-title"><span>Nossos serviços</span></h3>
        </div>
      </div>      
    </section>

    <section>
      <div class="container">
        <ul>
          <li
            class="flex flex-wrap justify-between pt-10 lg:pt-16 pb-10 lg:py-20 border-b border-borderBase border-opacity-20 js-scroll-activate">
            <div class="lhs md:w-2/5">
              <h2 class="section-title"><span>Diagnóstico</span> Estratégico</h2>
              <p class="mt-4 text-lg text-secondary leading-snug md:text-balance">Realizamos um raio-X completo do seu negócio</p>
            </div>
            <div class="rhs mt-10 md:mt-0 md:w-3/5 lg:w-2/5 md:pl-10 lg:pl-0">
              <ul class="star-list star-list--gray flex flex-wrap gap-y-6 md:gap-y-8">
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Análise de presença digital</h3>
                  <p class="mt-3 md:mt-4 text-lg text-secondary leading-6">Mapeamento da sua atuação on‑line para revelar potenciais de visibilidade e vendas.</p>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Forças e fraquezas da operação</h3>
                  <p class="mt-3 md:mt-4 text-lg text-secondary leading-6">Avaliação de processos internos e identificação de gargalos que impedem escalar.</p>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Mapa de oportunidades de crescimento</h3>
                  <p class="mt-3 md:mt-4 text-lg text-secondary leading-6">Cruzamento de dados de mercado e defini ações‑chave para os próximos três meses.</p>
                </li>
              </ul>
            </div>
          </li>
        </ul>
      </div>
    </section>


    <section>
      <div class="container">
        <ul>
          <li
            class="flex flex-wrap justify-between pt-10 lg:pt-16 pb-10 lg:py-20 border-b border-borderBase border-opacity-20 js-scroll-activate">
            <div class="lhs md:w-2/5">
              <h2 class="section-title"><span>Desenvolvimento</span> e Validação de Processos</h2>
              <p class="mt-4 text-lg text-secondary leading-snug md:text-balance">Construímos processos que sustentam equipes de alta performance e cultura organizacional alinhada.</p>
            </div>
            <div class="rhs mt-10 md:mt-0 md:w-3/5 lg:w-2/5 md:pl-10 lg:pl-0">
              <ul class="star-list star-list--black flex flex-wrap gap-y-6 md:gap-y-8">
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Mapeamento de processos‑chave</h3>
                  <p class="mt-3 md:mt-4 text-lg text-secondary leading-6">Documentação de cada etapa crítica para ganhar clareza e padronização.</p>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Criação de fluxos operacionais</h3>
                  <p class="mt-3 md:mt-4 text-lg text-secondary leading-6">Estruturação de  vendas, atendimento e entrega visando eficiência.
                  </p>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Validação focada em escalabilidade</h3>
                  <p class="mt-3 md:mt-4 text-lg text-secondary leading-6">Testei e ajustei os fluxos com a equipe, garantindo crescimento sustentável.</p>
                </li>
              </ul>
            </div>
          </li>
        </ul>
      </div>
    </section>


    <section>
      <div class="container">
        <ul>
          <li
            class="flex flex-wrap justify-between pt-10 lg:pt-16 pb-10 lg:py-20 border-b border-borderBase border-opacity-20 js-scroll-activate">
            <div class="lhs md:w-2/5">
              <h2 class="section-title"><span>Mentorias</span> em Grupo</h2>
              <p class="mt-4 text-lg text-secondary leading-snug md:text-balance">Guiamos grupos em trilhas práticas que aceleram resultados e fortalecem colaboração.</p>
            </div>
            <div class="rhs mt-10 md:mt-0 md:w-3/5 lg:w-2/5 md:pl-10 lg:pl-0">
              <ul class="star-list star-list--gray flex flex-wrap gap-y-6 md:gap-y-8">
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Encontros on‑line semanais</h3>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Materiais de apoio e trilha prática</h3>
                  </p>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Duração de 4 a 6 semanas</h3>
                </li>
              </ul>
            </div>
          </li>
        </ul>
      </div>
    </section>

    <section>
      <div class="container">
        <ul>
          <li
            class="flex flex-wrap justify-between pt-10 lg:pt-16 pb-10 lg:py-20 border-b border-borderBase border-opacity-20 js-scroll-activate">
            <div class="lhs md:w-2/5">
              <h2 class="section-title"><span>Posicionamento</span> de Marca</h2>
              <p class="mt-4 text-lg text-secondary leading-snug md:text-balance">Para pequenos negócios que querem ser lembrados pelo que entregam de melhor.</p>
            </div>
            <div class="rhs mt-10 md:mt-0 md:w-3/5 lg:w-2/5 md:pl-10 lg:pl-0">
              <ul class="star-list star-list--black flex flex-wrap gap-y-6 md:gap-y-8">
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Análise do cenário competitivo</h3>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Criação de narrativa e diferenciais claros</h3>
                  </p>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Ajustes de linguagem e tom de comunicação</h3>
                </li>
              </ul>
            </div>
          </li>
        </ul>
      </div>
    </section>
    
       <section>
      <div class="container">
        <ul>
          <li
            class="flex flex-wrap justify-between pt-10 lg:pt-16 pb-10 lg:py-20 border-b border-borderBase border-opacity-20 js-scroll-activate">
            <div class="lhs md:w-2/5">
              <h2 class="section-title"><span>Consultoria para Digitalização</span> de Negócios Locais</h2>
              <p class="mt-4 text-lg text-secondary leading-snug md:text-balance">Destinado para comércios físicos que querem vender online ou melhorar sua operação digital.</p>
            </div>
            <div class="rhs mt-10 md:mt-0 md:w-3/5 lg:w-2/5 md:pl-10 lg:pl-0">
              <ul class="star-list star-list--gray flex flex-wrap gap-y-6 md:gap-y-8">
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Escolha de canais (Instagram, WhatsApp, loja virtual)</h3>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Estratégia de vendas online</h3>
                  </p>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Integração com meios de pagamento e logística</h3>
                </li>
              </ul>
            </div>
          </li>
        </ul>
      </div>
    </section>

     <section>
      <div class="container">
        <ul>
          <li
            class="flex flex-wrap justify-between pt-10 lg:pt-16 pb-10 lg:py-20 border-b border-borderBase border-opacity-20 js-scroll-activate">
            <div class="lhs md:w-2/5">
              <h2 class="section-title"><span>Conselho como Serviço</h2>
              <p class="mt-4 text-lg text-secondary leading-snug md:text-balance">Você não está sozinho! Temos um time de especialistas como apoio contínuo na tomada de decisão.</p>
            </div>
            <div class="rhs mt-10 md:mt-0 md:w-3/5 lg:w-2/5 md:pl-10 lg:pl-0">
              <ul class="star-list star-list--black flex flex-wrap gap-y-6 md:gap-y-8">
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Reuniões mensais com conselheiros experientes</h3>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Discussão estratégica de temas-chave</h3>
                  </p>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Avaliação de resultados e próximos passos</h3>
                </li>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Acesso para consultas pontuais</h3>
                </li>
                 <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Ideal para pequenos negócios que querem maturidade de gestão sem contratar executivos</h3>
                </li>
              </ul>
            </div>
          </li>
        </ul>
      </div>
    </section>

    <section>
      <div class="container">
        <ul>
          <li
            class="flex flex-wrap justify-between pt-10 lg:pt-16 pb-10 lg:py-20 border-b border-borderBase border-opacity-20 js-scroll-activate">
            <div class="lhs md:w-2/5">
              <h2 class="section-title"><span>Conselheiro Líder Independente</h2>
              <p class="mt-4 text-lg text-secondary leading-snug md:text-balance">Ideal para organizações que buscam profissionalizar sua gestão, estruturar um conselho mais estratégico ou enfrentar desafios críticos com mais segurança e visão de longo prazo</p>
            </div>
            <div class="rhs mt-10 md:mt-0 md:w-3/5 lg:w-2/5 md:pl-10 lg:pl-0">
              <ul class="star-list star-list--gray flex flex-wrap gap-y-6 md:gap-y-8">
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Fortalecimento da governança corporativa</h3>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Visão estratégica externa e imparcial</h3>
                  </p>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Apoio em decisões críticas e transformações</h3>
                </li>
                </li>
                <li class="relative pl-10 w-full">
                  <i></i>
                  <h3 class="item-heading">Profissionalização da gestão empresarial</h3>
                </li>
              </ul>
            </div>
          </li>
        </ul>
      </div>
    </section>
    
    <section class="difference-list bg-base md:bg-black py-16 lg:py-24 relative">
      <div class="container relative text-white z-10">
        <div class="md:w-3/5 lg:w-2/5 ml-0 js-scroll-activate">
          <h2 class="section-title mb-2 md:mb-10 pt-56 md:pt-0">Por que escolher a <span>Hélio Amado?</span></h2>
          <ul class="js-toggle-parent" id="js-difference-slider">
            <li class="pl-12 md:pl-16 py-6 md:py-8 relative cursor-pointer js-toggle-slide is-active">
              <h3 class="item-heading">Proximidade com o cliente </h3>
              <p class="mt-4 leading-snug  js-toggle-target">Estabelecemos uma relação genuína de parceria, conhecendo profundamente sua empresa e seus desafios únicos.</p>
            </li>
            <li class="pl-12 md:pl-16 py-6 md:py-8 relative cursor-pointer js-toggle-slide ">
              <h3 class="item-heading">Estratégia personalizada</h3>
              <p class="mt-4 leading-snug hidden js-toggle-target">Cada solução é desenvolvida especificamente para sua realidade, com implementação viável e resultados mensuráveis.</p>
            </li>
            <li class="pl-12 md:pl-16 py-6 md:py-8 relative cursor-pointer js-toggle-slide ">
              <h3 class="item-heading">Resultados reais acompanhados</h3>
              <p class="mt-4 leading-snug hidden js-toggle-target">Acompanhamos de perto a implementação e medimos o impacto das estratégias no crescimento do seu negócio.</p>
            </li></li>
          </ul>
        </div>
      </div>
      <div class="absolute top-0 left-0 w-full h-80 md:h-full" id="js-difference-images">
        <img src="https://saxbr.com/wp-content/uploads/2019/05/sales-executive-confident-handshake-client-oriented-charisma-q8dqn1oh-scaled.jpeg.webp"
          class="absolute top-0 left-0 w-full h-full object-cover  transition-opacity duration-700 ease-in-out"
          role="presentation" alt="">
        <img src="https://www.sbs.ox.ac.uk/sites/default/files/Strategy%20website%20header.png"
          class="absolute top-0 left-0 w-full h-full object-cover opacity-0 transition-opacity duration-700 ease-in-out"
          role="presentation" alt="">
        <img src="https://www.dsgco.com/wp-content/uploads/2024/10/difference-3-scaled.jpg"
          class="absolute top-0 left-0 w-full h-full object-cover opacity-0 transition-opacity duration-700 ease-in-out"
          role="presentation" alt="">
      </div>
    </section>

  </main>

  <footer class="footer bg-base text-white pt-16 pb-12 lg:pt-24 lg:pb-16 relative overflow-hidden" id="contato">
    <div class="container flex flex-wrap justify-between relative z-10">
      <div class="w-full lg:w-2/5">
        <h2 class="section-title text-center lg:text-left">Entre em contato para uma conversa estratégica!</h2>
        <div class="md:flex md:justify-center lg:justify-start gap-x-4 mt-8 md:mt-10">
          <a href="https://wa.me/5511995316375?text=Olá!%20Gostaria%20de%20mais%20informações." target="_blank" rel="noopener" class="button button--white w-max mx-auto md:mx-0">Fale Conosco<i></i></a>
        </div>
      </div>
      <hr class="bg-white w-full opacity-60 my-14 lg:hidden">
      <div class="w-full lg:w-2/5 flex flex-wrap justify-between gap-y-10">
        <div class="lg:w-1/2">
          <h3 class="text-lg opacity-60">Entre em contato</h3>
          <ul class="space-y-3 mt-3">
            <li>
              <a href="https://wa.me/5511995316375?text=Olá!%20Gostaria%20de%20mais%20informações." target="_blank" rel="noopener" class="text-lg text-white leading-snug">(11) 99531-6375</a> <br>
              <a href="https://www.linkedin.com/in/helioalvesamado/" target="_blank" class="text-lg text-white leading-snug">in/helioalvesamado</a> <br>
              <a href="mailto:contato@helioamado.com.br" target="_blank" class="text-lg text-white leading-snug">contato@helioamado.com.br</a>
            </li>
          </ul>
        </div>
        <div class="lg:w-1/2">
          <h3 class="text-lg opacity-60">Legal</h3>
          <ul class="space-y-3 mt-3 pl-1">
            <?php
              $privacy_url = get_permalink( get_page_by_path( 'politica-de-privacidade' ) );
              $terms_url   = get_permalink( get_page_by_path( 'termos-de-uso' ) );
            ?>
            <li>
              <a href="<?php echo esc_url( $privacy_url ); ?>" target="_blank" class="text-lg text-white leading-snug">Política de Privacidade</a>
            </li>
            <li>
              <a href="<?php echo esc_url( $terms_url ); ?>" target="_blank" class="text-lg text-white leading-snug">Termos de Uso</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="container flex flex-wrap justify-between mt-16 lg:mt-10 relative z-10 mx-auto">
      <div class="footer__copyright w-full text-center mt-8">
        <small class="block lg:w-1/2 text-base text-white opacity-60">© 2025 Hélio Amado Consultores Associados. Todos os direitos reservados. </small>
        </div>
    </div>
    <div class="footer__gradients">
      <div class="footer__gradient-1"></div>
      <div class="footer__gradient-2"></div>
      <div class="footer__gradient-3"></div>
      <div class="footer__gradient-4"></div>
    </div>
  </footer>
  <div id="js-search-modal" class="modal js-modal">
    <div class="modal__close js-modal-close"></div>
    <div class="modal__content flex items-center justify-center">
      <form class="modal__search relative w-full" action="https://www.dsgco.com/">
        <i></i>
        <label for="js-search-modal-input" class="sr-only">Buscar site</label>
        <input type="text" name="s"
          class="text-lg py-3 md:py-4 pl-12 pr-3 md:pr-32 relative w-full bg-white rounded-full"
          placeholder="O que você procura?" id="js-search-modal-input">
        <input type="submit"
          class="button button--gold px-8 cursor-pointer w-full md:w-auto absolute -bottom-14 md:top-1.5 md:bottom-auto md:right-1.5 search-btn-a11y"
          value="Buscar">
      </form>
    </div>
  </div>
  <link rel="stylesheet" href="interactive-elements.css">
  <script src="https://www.dsgco.com//wp-content/plugins/facetwp/assets/vendor/fSelect/fSelect.js"></script>
  <script type="text/javascript"
    src="https://www.dsgco.com/wp-content/plugins/genesis-blocks/dist/assets/js/dismiss.js?ver=1732057515"
    id="genesis-blocks-dismiss-js-js"></script>
  <script type="text/javascript" src="https://www.dsgco.com/wp-content/themes/dsg/assets/app.js?ver=2025071100"
    id="app-script-js"></script>
  <script type="text/javascript"
    src="https://www.dsgco.com/wp-content/themes/dsg/assets/search-list-api.js?ver=2025071100" id="search-script-js">
  </script>
  <script defer src="/js/custom-footer.js"></script>
    <script>
  document.querySelectorAll('.header__nav a').forEach(function(link) {
    link.addEventListener('click', function() {
      // Fecha o menu removendo a classe 'is-open' do header
      document.querySelector('.header').classList.remove('is-open');
    });
  });
</script>
  <?php wp_footer(); ?>
</body>
</html>
